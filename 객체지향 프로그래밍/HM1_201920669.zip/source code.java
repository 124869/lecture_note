// Fig. 2.1: Welcome1.java
// Text-printing program.
// import java.lang.*; 

public class Welcome // if "Welcome" change to "come", get error
{ 
    public static void main(String[] args) // if deleting public, access modifier is "default"
    {  
       System.out.println("Welcome to Java Programming");
    } 
}
