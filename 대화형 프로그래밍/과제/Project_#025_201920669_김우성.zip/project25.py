"""
 Project25 튜플 프로그램 
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 데이터를 입력받아 수행하는 프로그램

 Input  :  작업

 Output  : 결과물

"""

print("튜플 활용하기")
print("튜플에 입력할 자료들을 차례로 입력하세요. 빈칸으로 구분합니다.")
data = input()
data = tuple(data.split()) # 입력값을 빈칸으로 구분지어 리스트를 만들고 튜플로 변환한다.

option = input("작업 할 내용을 입력하세요\n q=끝내기, s=슬라이싱, c=세기, i=존재여부 : ") # 옵션을 정한다.


while(option!='q'): # 각 입력에 따른 연산을 if문으로 구분지어 수행한다. 
    
    if(option == 's'):
        start = int(input("From  : "))
        finish = int(input("To : "))
        print(data[start:finish])
        
    elif(option == 'c'):
        value = input("찾는 자료 값은 : ")
        print(str(data.count(value))+'번 있습니다.')
        
    elif(option == 'i'):
        value = input("찾는 자료 값은 : ")
        if (data.count(value)):
            print('True')
        else:
            print('False')
        
    option = input("작업 할 내용을 입력하세요\n q=끝내기, s=슬라이싱, c=세기, i=존재여부 : ")
    
print("프로그램을 종료합니다.")
