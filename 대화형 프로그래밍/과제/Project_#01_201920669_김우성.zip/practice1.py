'''
예제 실습#1 - 정다면체 정보 출력

COPYRIGHT 2020 AJOU UNIVERSITY
pp
Author  : 김우성
Detail  : 정다면체들의 면의 수, 모서리의 수, 꼭지점의 수를 출력함
Input   : 없음
Output  : 정다면체들의 면의 수, 모서리의 수, 꼭지점의 수
Usage   : python practice1.py 
History : (1차) 2020년 3월 25일
'''
print("             면의 수      꼭지점의 수      모서리의 수")
print("정사면체          4                4                6")
print("정육면체          6                8               12")
print("정팔면체          8                6               12")
print("정십이면체       12               20               30")
print("정이십면체       20               12               30")
