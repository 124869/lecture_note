import math
x1=input("첫 번째 점의 x좌표를 입력하세요 : ")
y1=input("첫 번째 점의 y좌표를 입력하세요 : ")
x2=input("두 번째 점의 x좌표를 입력하세요 : ")
y2=input("두 번째 점의 y좌표를 입력하세요 : ")
x1=int(x1)
y1=int(y1)
x2=int(x2)
y2=int(y2)
result=abs(x1-x2)**2+abs(y1-y2)**2
result=math.sqrt(result)
print("두 점 ({},{}),({},{}) 사이의 거리는 {}입니다".format(x1,y1,x2,y2,result))
