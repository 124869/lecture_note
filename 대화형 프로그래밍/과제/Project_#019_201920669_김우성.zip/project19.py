"""

  COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 모양 출력 프로그램

 Input  :  모양 번호, 크기 

 Output  : 결과 모양

 File Name  : 과제2.py

 History  : 2020/05/29

"""
def alphabet(n):
    for i in range(9, 0, -2):
        print('{:^10}'.format('*' * i))
        
    for i in range(3, 11, 2):
        print('{:^10}'.format('*' * i))

def number(n):
    return 0

while(1):
    print("[모양 출력 프로그램]")
    print("[모양 번호: 1.알파벳 모래시계, 2. 숫자 리본]")
    
    a = int(input("출력할 모양을 선택하세요: "))
    if (a!=1 and a!=2):
        print("잘못 입력했습니다.")
        continue
    
    b = int(input("크기를  입력하세요: "))

    if (a==1):
        alphabet(b)
    elif(a==2):
        number(b)
    break


