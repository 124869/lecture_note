print("[주차 요금 계산 프로그램]") # 주차 요금 계산 프로그램 사이버보안학과 201920669 김우성
input_month=int(input("입차월: ")) # 입차날짜와 출차 날짜를 입력받는다.
input_day=int(input("입차일: "))
output_month=int(input("출차월: "))
output_day=int(input("출차일: "))

input=(input_month-1)*30+input_day # 각각의 날짜를 1월 1일을 기준으로 몇일인지 바꾼다.
input = input + input_month/2 - input_month%2 # 30일과 31일인 달의 차이를 메꾸기 위해 입차월의 나머지를 뺀다. 

output=(output_month-1)*30+output_day # 입차일과 같은 방식으로 구한다.
output = output + output_month/2 - output_month%2


day=int(output-input+1) # 입차일과 출차일의 차이에 1일을 더하여 총 주차 기간을 구한다.

result=day*3000-0.1*3000*int(day-199)*int(day/200) # 주차기간에 3000원을 곱한 후에 200일이 넘는 기간은 할인율을 적용하여 뺀다.
result=int(result) # 200일이 넘는 지를 구분하기 위해 day 나누기 200의 몫을 이용한다. 

print("총 주차 기간은 {} 일이고,\n주차 요금은 {} 원입니다.".format(day,result))
