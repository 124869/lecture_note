"""
 Project26 성적 프로그램
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 평균을 출력하는 프로그램

 Input  :  성적

 Output  : 평균

"""

score = ([80,90,88,75,91,65],[75,65,80,92],[90,90,88,95,70],[83,77,89,65,99])
# 전체 성적을 입력받는다. 


for i in range(len(score)): # 각 반별로 나누어 계산한다. 
    sum = 0
    for j in range(len(score[i])): # 각 반마다 점수를 다 더해 인원수로 나누어 평균을 구한다.
        sum = sum + score[i][j]
    print("{}반 평균 : {}".format(i+1,sum/len(score[i])))
