import math
s1=3; s2=math.sqrt(2**2+2**2);s3=math.sqrt(6**2+2**2);s4=5
print("구간별 소요 시간")
print("============================")
print("                 거리    소요시간")
print("첫 번째 구간     %.4f      %.4f"%(s1,s1/4))
print("두 번째 구간     %.4f      %.4f"%(s2,s2/2))
print("세 번째 구간     %.4f      %.4f"%(s3,s3/8))
print("네 번째 구간     %.4f      %.4f"%(s4,s4/4))
print("============================")
time=s1/4+s2/2+s3/8+s4/4
hour=int(time)
min=(time-hour)*60
sec=(min-int(min))*60
print("전체 소요 시간  %d시간%d분%d초"%(hour,min,sec))


