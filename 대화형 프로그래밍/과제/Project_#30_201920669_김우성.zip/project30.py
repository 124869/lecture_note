"""
 Project 고객평가에 따른 제품 판단 프로그램
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 제품의 평가 상태를 판단하여 우수와 판매불가 상품을 결정한다. 

 Input  :  제품의 평가상태

 Output  : 우수상품과 판매불가 상품

"""

name = ['비누','칫솔','샴푸','치약','로션'] # 초기 데이터
sales = [3,5,2,4,5]
customer = [2,4,1,4,3]
best = set()
worst =set()

for i in range(len(name)):
    if (sales[i] >=4 and customer[i] >=4): # 우수제품의 조건을 충족하는 항목을 집합에 추가한다.
        best.add(name[i])
        
    if (sales[i] < 4 and customer[i] < 4): # 판매불가 제품의 조건을 충족하는 항목을 집합에 추가한다.
        worst.add(name[i])
        
print("우수 제품: {}".format(best))
print("판매중지 제품: {}".format(worst))

        
if (sales[4] < 4 and customer[4] < 4): # 로션의 상태를 판단한다. 
    print("로션은 판매중지 제품입니다.")
else:
    print('로션은 판재중지 제품이 아닙니다.')
