"""
 Project 단어 수 계산 프로그램
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 문자열을 입력받아 단어 수를 출력한다. 

 Input  :  문자열

 Output  : 각 단어 수 

"""
a=input()
a=a.split() # 문자열을 리스트로 변환 

a_list = a # 중복을 허용하는 리스트와 그렇지 않을 리스트
a_list2  = list(set(a))

for i in range(len(a_list2)):
    count=0
    for j in range(len(a_list)):
        if a_list2[i] == a_list[j]: # 같은 값이 나오는 횟수만큼 count를 증가시킨다.
            count=count+1
    print(a_list2[i] + ":" + str(count))
    
