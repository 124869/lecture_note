sum=0 # 총 합을 0으로 초기화한다. 
keep='Y'
print("이 프로그램은 입력된 정수를 더하는 프로그램입니다.") # 정수를 입력받아 sum에 더한다
data=int(input("정수를 입력하세요 : "))
sum+=data
print("현재까지의 합은 {}입니다.".format(sum))

while keep!='N' and keep!='n':  
    keep=input("계속 하시겠습니까? : ") # 계속할지 말지를 분기문을 이용해 입력값으로 정한다. 
    if keep=='Y' or keep=='y':
        data=int(input("정수를 입력하세요 : "))
        sum+=data
        print("현재까지의 합은 {}입니다.".format(sum))
    elif keep=='N' or keep=='n': # 계속하지 않을경우 아무것도 출력하지 않는다. 
        print(" ")
    else:
        print("잘못 입력하셨습니다.") # yes no 둘다 아닌 값은 잘못된 값이므로 다시 while 문으로 돌아간다.
