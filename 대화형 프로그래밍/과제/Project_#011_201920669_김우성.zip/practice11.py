semester=int(input("몇 학기를 수료했는지 입력하세요 : "))
average=float(input("평균 학점을 입력하세요(4.5 만점) : "))

if 1<=semester<=8:
    if 4.0<=average:
        print("전액 장학금을 받을 수 있습니다.")
    elif 3.5<=average:
        print("등록금의 50%를 장학금으로 받을 수 있습니다.")
    elif 3.0<=average:
        print("등록금의 30%를 장학금으로 받을 수 있습니다.")
    else:
        print("장학금을 받을 수 없습니다.")
else:
    print("장학금을 받을 수 없습니다.")
