number=int(input("7~9자리 정수를 입력하세요 : "))
print("%d,%d,%d"%(number//1000//1000,number//1000%1000,number%1000))
