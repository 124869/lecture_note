"""
 Project22 음계 구하기
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 음계 구하는 문제.

 Input  :  계 이름

 Output  : 화음 3개, 학교종 음계

 File Name  : practice22.py

 History  : 2020/06/10

"""
data = ['도','레','미','파','솔','라','시']

print("1도 화음은 {}{}{}".format(data[0],data[2],data[4]))
print("4도 화음은 {}{}{}".format(data[3],data[5],data[1]))
print("5도 화음은 {}{}{}".format(data[4],data[6],data[1]))
print("학교종의 음계 : ['{}', '{}', '{}', '{}', '{}', '{}', '{}']".format(data[4],data[4],data[5],data[5],data[4],data[4],data[2]))
