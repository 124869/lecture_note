from random import randint

sum=0
average=0

print("번호       성적")
print("========================")

for n in range(1,31):  
    randNumber=randint(1,100)
    print("{}     {}".format(n,randNumber))
    sum+=randNumber
average=sum/30
print("총점       {}".format(sum))
print("평균       {}".format(average))
