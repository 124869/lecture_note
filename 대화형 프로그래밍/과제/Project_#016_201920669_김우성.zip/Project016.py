"""
 Project. 오일러 상수 출력
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 2진수를 10진수로 변환한다.  

 Input  : n

 Output  : 계산된 10진수의 숫자

 File Name  : project16.py

 History  : project 16 2020/05/22

"""

while(1):
    n=int(input("하나의 이진수를 입력하세요 : "))
    n2=n
    sum=0
    i=1
    while(n2>0):
        temp=n2%10
        n2=int(n2/10)
        
        if(temp != 1 and temp !=0):
            print("잘못된 이진수입니다. 다시 입력하세요")
            break
        
        sum=sum+temp*i
        i=i*2
        
    if(n2==0):
        print("이진수 {}을 십진법으로 표현한 값 = {}".format(n,sum))
        break
