"""
 과제 3

 사이버보안학과 201920669 김우성
 
 
"""

choice = 1
monthlist = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']
number = 0
booklist={}

def day_calculator(year1,month1,day1,year2, month2,day2):
    months = [31,28,31,30,31,30,31,31,30,31,30,31]
    
    if (year1 % 4 == 0 and year1 % 100 != 0) or (year1 % 400 == 0): # 윤년 여부를 검사한다. 
        months[1] = 29
    
    period1 = 0 
    period2 = 0

    for i in range(month1-1): # 각 날짜를 숫자로 변환에 차이를 구한다
        period1 = period1 + months[i]
    period1 = period1 + day1
    
    for i in range(month2-1):
        period2 = period2 + months[i]   
    period2 = period2 + day2

    if(year1 == year2): # 대출일과 반납일의 차이를 계산해 return 한다. 같은 해이면 그대로 빼고 다른해이면 그 해의 총 일수를 더한다.
        return period2 - period1
    else:
        while (year1 != year2):# 더하는 해가 윤년인지 아닌지를 판단한다.
            period2 = period2 + (366 if(year1 % 4 == 0 and year1 % 100 != 0) or (year1 % 400 == 0) else 365)
            year1 = year1 + 1
        return period2 - period1
    
    
def loan():
    global number
    if (number >= 3):
        print('현재 3권 모두 대출 중입니다.')
        return 1
    
    while(1):
        date = input('[대출일] 년, 월, 일을 입력하세요.(예: 2020 JAN 20): ')
        date = date.split() # 문자열로 받은 대출일을 리스트로 변환한다.
        date[0]=int(date[0])
        date[2]=int(date[2])
        
        if date[1] not in monthlist:
            print("월 입력이 잘못되었습니다.")
            continue
        else:
            date[1] = monthlist.index(date[1])+1 # date = [년, 월, 일 ]
            break
    
    flag=1
    while (flag):
        a = int(input('대출 권수 입력: '))
        number = number + a # 대출권수가 초과하면 다시 입력받는다. 
        
        if (number > 3):
            print('대출 가능한 권수를 초과했습니다.')
            flag = 1
            number = number - a 
        else:
            flag=0

    global booklist
    for i in range(a):
        book = input('대출할 도서명 입력: ') # 도서명을 입력받아 대출리스트에 추가한다. 
        booklist[book]=date

    while(1):
        keep = input('계속 하시겠습니까?(y 또는 n): ')
        if keep == 'y':
            return 1 
        elif keep == 'n':
            return 0 

def returnbook():
    global number
    
    if(booklist == {}):
        print("반납할 도서가 없습니다")
        return
    
    print("***********현재 대출 현황************")
    for i in range(number):
        year = list(booklist.values())[i][0] # i번째 책의 년/월/일
        month = list(booklist.values())[i][1]
        day = list(booklist.values())[i][2]
        bookname = list(booklist.keys())[i] # i번째 책의 이름
        print("[{}] 대출일: {}년 {}월 {}일, 도서명: {}".format(i+1,year, month, day, bookname))
    print('*************************************')

    while(1):
        date = input('[반납일] 년, 월, 일을 입력하세요.(예: 2020 JAN 20): ')
        date = date.split()
        date[0]=int(date[0])
        date[2]=int(date[2])
        
        if date[1] not in monthlist:
            print("월 입력이 잘못되었습니다.")
            continue
        else:
            date[1] = monthlist.index(date[1])+1 # date = [년, 월, 일 ]
            break
    

    bookname = input('반납할 도서명 입력: ') # 도서명은 오류가 없음 항상 참 
    loan_bookname = bookname
    loan_year = booklist[bookname][0]
    loan_month = booklist[bookname][1]
    loan_day = booklist[bookname][2]

    print("<{}> 도서의 대출일은 {}년 {}월 {}일이고, 반납일은 {}년 {}월 {}일입니다.".format(loan_bookname, loan_year, loan_month, loan_day, date[0], date[1], date[2]))

    load_period = day_calculator(loan_year,loan_month,loan_day,date[0], date[1],date[2]) # 대출기간을 계산하는 함수
    print("대출 기간은 총 {}일입니다.\n".format(load_period))

    if(load_period > 50): # 50일부터 연체가 시작된다. 
        print("{}일 연채되었습니다".format(load_period-50))
    print("반납이 완료되었습니다.")
    number = number - 1

    del booklist[bookname]

    while(1):
        keep = input('계속 하시겠습니까?(y 또는 n): ')
        if keep == 'y':
            return 1 
        elif keep == 'n':
            return 0 

print("[도서 대출 반납 프로그램]")
while(choice):
    print("[1. 대출, 2. 반납]")
    choice = input('서비스 번호를 선택하세요: ') # 서비스 번호를 입력받아 각각의 함수를 실행하고 잘못된 경우 다시 입력 받는다. 
    if choice == '1':
        choice = loan()
    elif choice == '2':
        choice = returnbook()
    else:
        print('서비스 번호를 잘못 입력했습니다.')
        continue

