"""
 Project 줄임말 풀어쓰기
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 줄임말을 풀어서 일반적인 문자으로 변환

 Input  :  줄임말

 Output  : 일반 문장

"""
data = {'B4':'Before', 'TX':'Thanks', 'BBL':'Be Back Later','BCNU':'Be Seeing You'
        , 'HAND' : 'Have A Nice Day'} # 줄임말 리스트

str = input('번역할 문장을 입력하세요')
keylist = list(data.keys()) # key 값을 리스트로 뽑아낸다.

for i in range(len(keylist)):
    if (keylist[i] in str): # 일치하는 key를 찾아 원래 말로 바꾼다. 
        str = str.replace(keylist[i], data[keylist[i]])
        break

print(str)
