pen=input("볼펜 개수 입력 : ")
pen=int(pen)
note=input("노트 개수 입력 : ")
note=int(note)
result=pen*1000+note*3000

if result>10000 :
    print("총 금액의 15%가 할인되었습니다.")
    result=int(result*0.85)
print("총 금액 : {} 원".format(result))
