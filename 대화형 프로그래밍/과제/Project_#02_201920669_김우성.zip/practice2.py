a=10
b=500
temp=a
a=b
b=temp
print(a)
print(b)
