Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> str="Python"
>>> str[-1:0]
''
>>> str[-1:0:-1]
'nohty'
>>> str[-1:1:-1]
'noht'
>>> str[-1:-1:-1]
''
>>> str[::-1]
'nohtyP'
>>> str[0:]
'Python'
>>> str[:-1]
'Pytho'
>>> str[:0]
''
>>> str[:6]
'Python'
>>> str[:]
'Python'
>>> str[-6:0]
''
>>> ord(82)
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    ord(82)
TypeError: ord() expected string of length 1, but int found
>>> ord('a')
97
>>> str="abcd"
>>> str[5]
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    str[5]
IndexError: string index out of range
>>> 