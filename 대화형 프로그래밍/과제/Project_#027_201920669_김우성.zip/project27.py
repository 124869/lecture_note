"""
 Project 커피 판매 프로그램
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 메뉴를 입력받아 가격을출력

 Input  :  메뉴

 Output  : 가

"""
option = 1
data = {'Americano':4000, 'Cafe latte':4500, 'Cappuccino':5000, 'Vanilla latte':5500}
keylist = list(data.keys())
while(1):
    option = input("메뉴 입력(q = 종료)")
    
    if(option == 'q'):
        break
    
    option = option.capitalize()
    
    if(option in keylist):
        print(option +"는 "+str(data[option])+" 원 입니다.")
    else:
        print('메뉴에 없는 커피를 입력했습니다.')
