print("이 놀이기구를 타러면 다음의 지시사항을 따라주세요")
height=input("키를 입력하세요 : ")
weight=input("몸무게를 입력하세요 : ")
height=int(height)
weight=int(weight)
if height<=150 and weight<=40 :
    print("입장가능합니다.")
else :
    print("입장이 불가능합니다.")
    print("다른 놀이기구를 이용해주세요")
