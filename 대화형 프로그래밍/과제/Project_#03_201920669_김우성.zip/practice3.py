Qsec=10000+1014
sec=Qsec%60

Qsec=int(Qsec/60)
min=Qsec%60

Qsec=int(Qsec/60)
hour=Qsec%60

print("Sec :",sec)
print("Min :",min)
print("Hour :",hour)
