"""
 Project18 계산기 만들기
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 사칙연산을 수행하는 계산기 프로그램을 만든다

 Input  :  사칙연산 선택자, 두 개의 인수

 Output  : 결과값

 File Name  : practice18.py

 History  : 2020/05/27

"""
def sum(n1,n2):
    print("결과: ",n1+n2)

def sub(n1,n2):
    print("결과: ",abs(n1-n2))

def mul(n1,n2):
    print("결과: ",n1*n2)

def div(n1,n2):
    print("결과: ",n1/n2)



    
print("계산기 프로그램")

while(1):
   
    option = int(input("1.덧셈 2.뺄셈 3.곱셈 4.나눗셈 5.종료: "))
    
    if (option==5):
        break
    
    n1 = float(input("정수 입력1: "))
    n2 = float(input("정수 입력2: "))

    if option == 1:
        sum(n1,n2)
    elif option == 2:
        sub(n1,n2)
    elif option == 3:
        mul(n1,n2)
    elif option == 4:
        div(n1,n2)
    


