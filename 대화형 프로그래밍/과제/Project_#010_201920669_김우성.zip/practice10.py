gender=input("성별을 입력하세요(F/M) : ")
age=int(input("나이를 입력하세요 : "))
money=int(input("적립금을 입력하세요 : "))
if(gender=='M'):
    result=money*2
else:
    if(age<20):
        result=money*1.5
    if(20<=age<30):
        result=money*2
    if(30<=age<40):
        result=money*2.5
    if(40<age):
        result=money*3
print("당신의 적립 금액은 {}와 같습니다.".format(result))
