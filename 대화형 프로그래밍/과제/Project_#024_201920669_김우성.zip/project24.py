"""
 Project24 메세지 프로그램
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 학생들에게 메세지를 보낸다

 Input  :  X

 Output  : 10명의 이름이 담긴 각각의 메세지

 File Name  : practice24.py

 History  : 2020/06/12

"""
name = ['김','이','박','최','감','가','임','오','자','강']

for i in range(10):
    print("{} 학우에게".format(name[i]))
    print("내일 오후 6시부터 팔달관 로비에서 개강총회가 진행되니 참석바랍니다.")
    print("학생 대표 홍길동")
    print("\n-------------------------------------------")
