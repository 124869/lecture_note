"""
 Project. 오일러 상수 출력
 
 COPYRIGHT 2020 AJOU University

 Author : 사이버보안학과 201920669 김우성

 Details : 1/n!를 계속 더해 오일러 상수의 가까운 값을 찾는다. 

 Input  : n

 Output  : 계산된 오일러 상수의 추정치

 File Name  : project15.py

 History  : project 15 2020/05/22

"""
n=int(input("n : "))

result=1
temp=2
for i in range (1,n+1):
    a=1
    for j in range(1,i+1):      
        a=a*j  
    if (temp-1/a<10**(-300)):
        break
    
    temp=1/a
    result=result+1/a

print("n = {}일 때, 값은 {}입니다.".format(n,result))
